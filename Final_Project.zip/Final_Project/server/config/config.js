'use strict';

module.exports = {
  apiinput: {
    inputkeyword: '',
    inputlocation: '',
    inputradius: ''
  }
};
