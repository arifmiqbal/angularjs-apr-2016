(function() {
  'use strict';

  angular
    .module('template', [
    	'ngAnimate',
    	'ngResource',
    	'ngSanitize',
	    'ui.router',
	    'ui.bootstrap',
	    'MyApp.Home',
	    'MyApp.Contacts',
	    'MyApp.Store'

	]);

})();
